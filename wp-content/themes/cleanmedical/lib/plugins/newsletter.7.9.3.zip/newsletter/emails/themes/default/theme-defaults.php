<?php

$theme_defaults = array(
    'theme_background' => '#f4f4f4',
    'theme_color' => '#555555',
    'theme_max_posts' => 10,
    'theme_image_size' => 'thumbnail' 
);

