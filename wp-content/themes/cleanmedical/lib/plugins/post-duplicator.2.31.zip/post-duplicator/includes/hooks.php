<?php

// function testingssss() {
// 	$original_id = get_the_id();
// 	$post_type = 'page';
// 	$taxonomies = get_object_taxonomies( $post_type );
// 	foreach( $taxonomies as $taxonomy ) {
// 		$terms = wp_get_post_terms( $original_id, $taxonomy, array('fields' => 'names') );
// 		$object_terms = wp_get_object_terms( $original_id, $taxonomy );
// 	//	wp_set_object_terms( $duplicate_id, $terms, $taxonomy );
// 	}
// }
// add_action( 'wp', 'testingssss' );		